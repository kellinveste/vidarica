import { motion } from 'framer-motion'

export default function App() {
  return (
    <main className="flex items-center justify-center h-screen bg-gradient-to-br from-purple-100 to-purple-300">
      <motion.div
        className="text-center max-w-xl p-6 bg-white rounded-2xl shadow-xl"
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        <h1 className="text-4xl font-bold text-purple-700 mb-4">Mentoria Vida Rica</h1>
        <p className="text-lg text-gray-700">Organização financeira estratégica e prática para você prosperar com propósito.</p>
        <a href="https://wa.me/5584997054861" target="_blank" className="inline-block mt-6 px-6 py-3 bg-purple-700 text-white rounded-xl shadow hover:bg-purple-800 transition">
          Fale comigo no WhatsApp
        </a>
      </motion.div>
    </main>
  )
}